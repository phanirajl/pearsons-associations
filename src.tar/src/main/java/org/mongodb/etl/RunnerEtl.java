package org.mongodb.etl;

import com.mongodb.client.model.InsertManyOptions;
import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoCollection;
import org.bson.Document;

public class RunnerEtl {

    protected MongoClient client;
    protected int batchSize = 20000;
    protected MongoCollection<Document> src;
    protected MongoCollection<Document> tgt;
    protected InsertManyOptions options;
}
